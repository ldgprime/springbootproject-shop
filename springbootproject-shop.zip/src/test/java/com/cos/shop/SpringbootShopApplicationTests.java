package com.cos.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
