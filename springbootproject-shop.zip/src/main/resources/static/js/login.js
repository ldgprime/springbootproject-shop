/**
 * 
 */



$('#login--submit').on('click', function(e) {
	// e.preventDefault();
	var data = {
		username : $('#username').val(),
		password : $('#password').val()
	};
	$.ajax({
		type : 'POST',
		url : '/user/login',
		data : JSON.stringify(data),
		contentType : 'application/json; charset=utf-8',
		dataType : 'json'
	}).done(function(r) {
		alert("로그인 성공");
		location.href = '/';
	}).fail(function(r) {
		alert("로그인 실패");
	});
});

//엔터키 치면 바로 로그인 되게
$("#password").keydown(function(key) {
	if (key.keyCode == 13) {// 키가 13이면 실행 (엔터는 13)
		$('#login--submit').click();
	}
});