package com.cos.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cos.shop.model.review.dto.ReqReviewDto;
import com.cos.shop.model.review.dto.RespReviewDto;
import com.cos.shop.model.user.User;
import com.cos.shop.repository.ReviewRepository;

@Service
public class ReviewService {

	@Autowired
	private ReviewRepository reviewRepository;

	public List<RespReviewDto> 리뷰목록보기(int productId) {

		return reviewRepository.findByProductId(productId);
	}
	
	public RespReviewDto 리뷰쓰기(ReqReviewDto dto) {
		int result = reviewRepository.save(dto);
		
		System.out.println("ReviewService id: "+dto.getId());
		
		if(result == 1) {
			return reviewRepository.findById(dto.getId());
		}else {
			return null;
		}
		
	}
	
//	public int 리뷰삭제(int id) {
//		RespReviewDto review = reviewRepository.findById(id);
		
//		// 지금 로그인 주체는 누구냐?
//		User principal = (User) session.getAttribute("principal");
//		User principal = userDetailService.getPrincipal();
//		if(comment.getUserId() == principal.getId()) {
//			return commentRepository.delete(id); // 1, 0, -1
//		}else {
//			return ReturnCode.권한없음; // -3
//		}		
//	}	
	
}