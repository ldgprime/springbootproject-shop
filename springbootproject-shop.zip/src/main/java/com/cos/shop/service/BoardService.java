package com.cos.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cos.shop.model.board.dto.ReqWriteDto;
import com.cos.shop.model.board.dto.RespBoardDto;
import com.cos.shop.model.review.dto.RespReviewDto;
import com.cos.shop.repository.BoardRepository;

@Service
public class BoardService {

	@Autowired
	private BoardRepository boardRepository;
	
	public int 글쓰기(ReqWriteDto dto) {
		return boardRepository.save(dto);
	}
	public List<RespBoardDto> 문의목록보기(int productId) {

		return boardRepository.findByProductId(productId);
	}

}