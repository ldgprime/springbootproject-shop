package com.cos.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cos.shop.model.comment.dto.ReqCommentDto;
import com.cos.shop.model.comment.dto.RespCommentDto;
import com.cos.shop.repository.CommentRepository;


@Service
public class CommentService {
	
	@Autowired
	private CommentRepository commentRepository;

	public List<RespCommentDto> 문의리플보기(int productId) {

		return commentRepository.findByProductId(productId);
	}
	
	public RespCommentDto 리뷰쓰기(ReqCommentDto dto) {
		int result = commentRepository.save(dto);
		
		System.out.println("CommentService id: "+dto.getId());
		
		if(result == 1) {
			return commentRepository.findById(dto.getId());
		}else {
			return null;
		}
		
	}



}