package com.cos.shop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cos.shop.model.user.User;
import com.cos.shop.repository.UserRepository;

//@Service
//public class MyUserDetailService implements UserDetailsService{

@Service
public class MyUserDetailService {	
	
	@Autowired
	private UserRepository userRepository;
	
	private User user;
	
	public User getPrincipal() {
		return user;
	}
	
	
	
}
