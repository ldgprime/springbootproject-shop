package com.cos.shop.model.comment.dto;

import java.sql.Date;

import com.cos.shop.model.RespCM;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RespCommentDto {
	
	private RespCM status;
	
	private int id;
	private String title;
	private String content;
	private int boardId;
	private int userId;
	private int productId;
	private Date createDate;
	

}
