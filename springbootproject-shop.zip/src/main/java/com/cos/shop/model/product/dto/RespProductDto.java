package com.cos.shop.model.product.dto;

import java.sql.Date;

import com.cos.shop.model.RespCM;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RespProductDto {
	
	private RespCM status;
	
	private int id;
	private String productName;
	private int productPrice;
	private int likeCount;
	private int hateCount;
	

}
