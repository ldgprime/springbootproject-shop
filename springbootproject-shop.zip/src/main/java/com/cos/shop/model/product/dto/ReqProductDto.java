package com.cos.shop.model.product.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReqProductDto {
	
	private int id;
	private String productName;
	private int productPrice;
	private int likeCount;
	private int hateCount;
	
}
