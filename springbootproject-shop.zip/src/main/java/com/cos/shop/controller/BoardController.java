package com.cos.shop.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cos.shop.model.RespCM;
import com.cos.shop.model.board.dto.ReqWriteDto;
import com.cos.shop.model.user.User;
import com.cos.shop.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	@Autowired
	private HttpSession session;

	@GetMapping("/board/boardwrite")
	public String boardWrite() {
		return "/board/boardwrite";
	}

	@GetMapping("/board/boardupdate")
	public String boardupdate() {
		return "/board/boardupdate";
	}

	@GetMapping("/board/boarddetail")
	public String boardDetail() {
		return "/board/boarddetail";
	}
	
	

	@PostMapping("/board/boardwrite")
	public ResponseEntity<?> write(@RequestBody ReqWriteDto dto) {

		User principal = (User) session.getAttribute("principal");

		dto.setUserId(principal.getId());

		int result = boardService.글쓰기(dto);

		if (result == 1) {
			return new ResponseEntity<RespCM>(new RespCM(200, "ok"), HttpStatus.OK);
		} else {
			return new ResponseEntity<RespCM>(new RespCM(400, "fail"), HttpStatus.BAD_REQUEST);
		}

	}

}
