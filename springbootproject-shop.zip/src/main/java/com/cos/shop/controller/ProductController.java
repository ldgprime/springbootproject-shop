package com.cos.shop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;


import com.cos.shop.model.review.dto.ReqReviewDto;
import com.cos.shop.repository.ReviewRepository;
import com.cos.shop.service.BoardService;
import com.cos.shop.service.CommentService;
import com.cos.shop.service.ProductService;
import com.cos.shop.service.ReviewService;

@Controller
public class ProductController {

	@Autowired
	private ReviewService reviewService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private BoardService boardService;
	
	@Autowired
	private ReviewRepository reviewRepository;

	@GetMapping({ "/", "", "/index" })
	public String index() {
		return "index";
	}

	@GetMapping("/product/bill")
	public String bill() {
		return "/product/bill";
	}

	@GetMapping("/product/cart")
	public String cart() {
		return "/product/cart";
	}

	@GetMapping("/product/product")
	public String product() {
		return "/product/product";
	}

	@GetMapping("/product/productdetail")
	public String productDetail() {
		return "/product/productdetail";
	}
	
	@PostMapping("/product/productdetail")
	public @ResponseBody String Review(@RequestBody ReqReviewDto reqReviewDto) {
		
		int result = reviewRepository.save(reqReviewDto);
		
		if(result == 1) {
			return "ok"; // 뷰리졸브가 컨트롤러 타서 인식함 그래서 인트 앞에 리스폰스바디 붙여야
		}else {
			return "fail";
		}	
	}
	

	// 인증 체크
	@GetMapping("/product/productdetail/{id}")
	public String detail(@PathVariable int id, Model model) {

		model.addAttribute("reviews", reviewService.리뷰목록보기(id));
		model.addAttribute("product", productService.상품목록보기(id));
		model.addAttribute("boards", boardService.문의목록보기(id));
		

		return "/product/productdetail";
	}

}