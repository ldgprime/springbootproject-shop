package com.cos.shop.repository;

import java.util.List;


import com.cos.shop.model.user.User;
import com.cos.shop.model.user.dto.ReqJoinDto;
import com.cos.shop.model.user.dto.ReqLoginDto;

public interface UserRepository {
	int save(ReqJoinDto dto);
	int findByUsername(String username); 
	User authentication(String username);
	User findByUsernameAndPassword(ReqLoginDto dto);
	int checkOverId(String username);
	int update(int id, String password, String profile);
	User findById(int id);
}
