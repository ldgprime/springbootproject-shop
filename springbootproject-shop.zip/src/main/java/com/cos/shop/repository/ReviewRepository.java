package com.cos.shop.repository;

import java.util.List;

import com.cos.shop.model.review.dto.ReqReviewDto;
import com.cos.shop.model.review.dto.RespReviewDto;

public interface ReviewRepository {

	public List<RespReviewDto> findByProductId(int productId);
	public int save(ReqReviewDto dto);
	public int delete(int id);
	public RespReviewDto findById(int id);
}
