package com.cos.shop.repository;

import java.util.List;


import com.cos.shop.model.product.dto.RespProductDto;


public interface ProductRepository {

	public List<RespProductDto> findById(int id);

}
