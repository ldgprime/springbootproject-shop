package com.cos.shop.repository;

public interface HateRepository {

}
