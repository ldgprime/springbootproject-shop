package com.cos.shop.repository;

import java.util.List;


import com.cos.shop.model.board.Board;
import com.cos.shop.model.comment.dto.ReqCommentDto;
import com.cos.shop.model.comment.dto.RespCommentDto;
import com.cos.shop.model.user.User;

public interface CommentRepository {
	
	public List<RespCommentDto> findByProductId(int productId);
	public int save(ReqCommentDto dto);
	public int delete(int id);
	public RespCommentDto findById(int id);
}

