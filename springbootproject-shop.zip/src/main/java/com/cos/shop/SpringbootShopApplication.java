package com.cos.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootShopApplication.class, args);
	}

}
